
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MenuIcon, X, ShoppingBag } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useCart } from '@/contexts/CartContext';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { totalItems } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav 
      className={cn(
        "fixed w-full top-0 z-50 transition-all duration-300",
        isScrolled 
          ? "py-3 bg-nothing-black/90 backdrop-blur-md shadow-lg" 
          : "py-5 bg-transparent"
      )}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link to="/" className="flex items-center">
          <span className="text-2xl font-bold font-playfair text-gold-gradient animate-gold-shimmer">NOTHING</span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          <a href="#featured-products" className="text-gray-300 hover:text-white transition-colors duration-300">Products</a>
          <a href="#features" className="text-gray-300 hover:text-white transition-colors duration-300">Features</a>
          <a href="#testimonials" className="text-gray-300 hover:text-white transition-colors duration-300">Testimonials</a>
          <Link to="/checkout" className="relative">
            <ShoppingBag className="text-gray-300 hover:text-white transition-colors duration-300" />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-nothing-gold text-nothing-black text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </Link>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center">
          <Link to="/checkout" className="relative mr-6">
            <ShoppingBag className="text-gray-300 hover:text-white transition-colors duration-300" />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-nothing-gold text-nothing-black text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </Link>
          <button 
            onClick={() => setIsOpen(!isOpen)}
            className="text-gray-300 hover:text-white focus:outline-none"
          >
            {isOpen ? <X size={24} /> : <MenuIcon size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div 
        className={cn(
          "fixed inset-0 bg-nothing-black/95 backdrop-blur-md flex flex-col items-center justify-center transition-all duration-500 z-40",
          isOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        )}
      >
        <div className="flex flex-col items-center space-y-8 text-xl">
          <a 
            href="#featured-products" 
            className="text-gray-300 hover:text-white transition-colors duration-300"
            onClick={() => setIsOpen(false)}
          >
            Products
          </a>
          <a 
            href="#features" 
            className="text-gray-300 hover:text-white transition-colors duration-300"
            onClick={() => setIsOpen(false)}
          >
            Features
          </a>
          <a 
            href="#testimonials" 
            className="text-gray-300 hover:text-white transition-colors duration-300"
            onClick={() => setIsOpen(false)}
          >
            Testimonials
          </a>
          <Link 
            to="/checkout" 
            className="text-gray-300 hover:text-white transition-colors duration-300"
            onClick={() => setIsOpen(false)}
          >
            Checkout
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
