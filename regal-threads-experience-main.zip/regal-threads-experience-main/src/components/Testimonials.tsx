
import React, { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  content: string;
  avatar: string;
  rating: number;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Rohit Kumar",
    role: "GEC Samastipur",
    content: "NOTHING isn't just a brand, it's a statement. When I wear their T-shirts on campus, people notice. The quality is exceptional and the designs are truly unique.",
    avatar: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80",
    rating: 5
  },
  {
    id: 2,
    name: "Shivam Singh",
    role: "GEC Samastipur",
    content: "These T-shirts have become my go-to for important events on campus. The premium feel and elegant design perfectly complement the prestige of our institution.",
    avatar: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80",
    rating: 5
  },
  {
    id: 3,
    name: "Monu Yadav",
    role: "GEC Samastipur",
    content: "I've never felt more confident than when wearing my NOTHING T-shirt. It's not just clothing; it's an experience that makes you feel part of something exclusive.",
    avatar: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80",
    rating: 5
  }
];

const Testimonials: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);
  const testimonialRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  useEffect(() => {
    const startAutoplay = () => {
      intervalRef.current = setInterval(() => {
        nextTestimonial();
      }, 6000);
    };

    startAutoplay();

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && testimonialRef.current) {
            testimonialRef.current.classList.add('animate-fade-in');
          }
        });
      },
      { threshold: 0.2 }
    );

    if (testimonialRef.current) {
      observer.observe(testimonialRef.current);
    }

    return () => {
      if (testimonialRef.current) {
        observer.unobserve(testimonialRef.current);
      }
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      className="py-20 px-4 bg-nothing-black relative overflow-hidden"
    >
      <div className="absolute top-0 left-0 w-full h-full opacity-5">
        <div className="absolute inset-0 bg-gradient-to-b from-nothing-gold/10 to-transparent"></div>
      </div>

      <div className="container mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-4">
            Royal <span className="text-gold-gradient animate-gold-shimmer">Experiences</span>
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Hear what our esteemed customers have to say about their journey with NOTHING.
          </p>
        </div>

        <div 
          ref={testimonialRef}
          className="max-w-4xl mx-auto opacity-0"
        >
          <div className="relative">
            <div className="overflow-hidden relative">
              <div 
                className="transition-transform duration-500 ease-in-out flex"
                style={{ transform: `translateX(-${activeIndex * 100}%)` }}
              >
                {testimonials.map((testimonial) => (
                  <div 
                    key={testimonial.id} 
                    className="min-w-full px-4"
                  >
                    <div className="bg-nothing-charcoal/40 backdrop-blur-sm p-8 rounded-lg gold-border-gradient">
                      <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 mb-6">
                        <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-nothing-gold flex-shrink-0">
                          <img 
                            src={testimonial.avatar} 
                            alt={testimonial.name} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="text-center sm:text-left">
                          <h3 className="text-xl font-semibold font-playfair">{testimonial.name}</h3>
                          <p className="text-gray-400 mb-2">{testimonial.role}</p>
                          <div className="flex justify-center sm:justify-start">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star 
                                key={i} 
                                size={16} 
                                className={cn(
                                  i < testimonial.rating ? "text-nothing-gold" : "text-gray-600",
                                  "fill-current"
                                )} 
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                      <p className="text-gray-300 italic text-lg">{testimonial.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button 
              onClick={prevTestimonial}
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-2 md:-translate-x-6 bg-nothing-charcoal text-white p-2 rounded-full shadow-lg hover:bg-nothing-gold hover:text-nothing-black transition-colors duration-300"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={20} />
            </button>

            <button 
              onClick={nextTestimonial}
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-2 md:translate-x-6 bg-nothing-charcoal text-white p-2 rounded-full shadow-lg hover:bg-nothing-gold hover:text-nothing-black transition-colors duration-300"
              aria-label="Next testimonial"
            >
              <ChevronRight size={20} />
            </button>
          </div>

          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={cn(
                  "w-3 h-3 rounded-full transition-all duration-300",
                  index === activeIndex 
                    ? "bg-nothing-gold scale-110" 
                    : "bg-gray-600 hover:bg-gray-400"
                )}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
