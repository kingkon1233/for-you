
import React from 'react';
import { Instagram, Twitter, Facebook, Youtube, Mail, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-nothing-black text-white py-16 border-t border-gray-800">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <h3 className="font-playfair text-2xl mb-6 text-gold-gradient animate-gold-shimmer">NOTHING</h3>
            <p className="text-gray-400 mb-6">
              Your college identity, your statement. We create custom college t-shirts that reflect your pride and excellence.
            </p>
            <div className="flex space-x-4">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                <Instagram size={20} />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                <Twitter size={20} />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                <Facebook size={20} />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                <Youtube size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-playfair text-lg mb-6 text-white">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                  Home
                </Link>
              </li>
              <li>
                <a href="#featured-products" className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                  Collections
                </a>
              </li>
              <li>
                <a href="#features" className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                  About Us
                </a>
              </li>
              <li>
                <a href="#testimonials" className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                  Testimonials
                </a>
              </li>
              <li>
                <a href="#newsletter" className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                  Contact
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-playfair text-lg mb-6 text-white">About Us</h4>
            <p className="text-gray-400 mb-4 text-sm leading-relaxed">
              Founded in 2023, NOTHING is dedicated to providing high-quality college t-shirts that help students express their identity and college pride. We believe in sustainable fashion and ethical manufacturing.
            </p>
            <p className="text-gray-400 text-sm leading-relaxed">
              Our team is passionate about delivering exceptional quality and unique designs that make you stand out on campus. Each product is carefully crafted with attention to detail and comfort.
            </p>
          </div>
          
          <div>
            <h4 className="font-playfair text-lg mb-6 text-white">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <Mail size={20} className="text-nothing-gold mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-300 mb-1">Email Us</p>
                  <a href="mailto:support@nothing.com" className="text-gray-400 hover:text-nothing-gold transition-colors">support@nothing.com</a>
                </div>
              </li>
              <li className="flex items-start space-x-3">
                <Phone size={20} className="text-nothing-gold mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-300 mb-1">Call Us</p>
                  <a href="tel:+18006684464" className="text-gray-400 hover:text-nothing-gold transition-colors">+1 (800) NOTHING</a>
                </div>
              </li>
            </ul>
            
            <div className="mt-6 pt-4 border-t border-gray-700">
              <h5 className="text-white mb-2">Policies</h5>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <a href="/terms" onClick={(e) => { e.preventDefault(); alert('Terms & Conditions: Our t-shirts are designed for college students. Returns accepted within 7 days of delivery.'); }} className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                  Terms & Conditions
                </a>
                <a href="/privacy" onClick={(e) => { e.preventDefault(); alert('Privacy Policy: We collect minimal data required for order processing and delivery. Your information is secure with us.'); }} className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                  Privacy Policy
                </a>
                <a href="/shipping" onClick={(e) => { e.preventDefault(); alert('Shipping Policy: Free delivery to your college campus. Other locations have standard shipping rates.'); }} className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                  Shipping Policy
                </a>
                <a href="/returns" onClick={(e) => { e.preventDefault(); alert('Returns & Exchanges: Unworn items can be exchanged or returned within 7 days. Contact our support team.'); }} className="text-gray-400 hover:text-nothing-gold transition-colors duration-300">
                  Returns Policy
                </a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-16 pt-8 border-t border-gray-800 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} NOTHING. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
