
import React from 'react';

interface CheckoutStepsProps {
  currentStep: 'cart' | 'shipping' | 'payment' | 'confirmation';
  onStepClick: (step: 'cart' | 'shipping' | 'payment') => void;
  isCartValid: boolean;
  isShippingValid: boolean;
}

const CheckoutSteps: React.FC<CheckoutStepsProps> = ({ 
  currentStep, 
  onStepClick,
  isCartValid,
  isShippingValid
}) => {
  if (currentStep === 'confirmation') return null;
  
  return (
    <div className="mb-10">
      <div className="flex justify-between">
        <div 
          className={`flex flex-col items-center ${currentStep === 'cart' ? 'text-nothing-gold' : 'text-gray-500'}`}
          onClick={() => isCartValid && onStepClick('cart')}
          style={{ cursor: isCartValid ? 'pointer' : 'default' }}
        >
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 ${currentStep === 'cart' ? 'bg-nothing-gold text-nothing-black' : 'bg-gray-800 text-gray-500'}`}>
            1
          </div>
          <span className="text-sm">Cart</span>
        </div>
        
        <div className="flex-1 flex items-center px-4">
          <div className={`h-0.5 w-full ${currentStep === 'cart' ? 'bg-gray-700' : 'bg-nothing-gold'}`}></div>
        </div>
        
        <div 
          className={`flex flex-col items-center ${currentStep === 'shipping' ? 'text-nothing-gold' : 'text-gray-500'}`}
          onClick={() => isCartValid && onStepClick('shipping')}
          style={{ cursor: isCartValid ? 'pointer' : 'default' }}
        >
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 ${currentStep === 'shipping' ? 'bg-nothing-gold text-nothing-black' : 'bg-gray-800 text-gray-500'}`}>
            2
          </div>
          <span className="text-sm">Shipping</span>
        </div>
        
        <div className="flex-1 flex items-center px-4">
          <div className={`h-0.5 w-full ${currentStep === 'payment' ? 'bg-nothing-gold' : 'bg-gray-700'}`}></div>
        </div>
        
        <div 
          className={`flex flex-col items-center ${currentStep === 'payment' ? 'text-nothing-gold' : 'text-gray-500'}`}
        >
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 ${currentStep === 'payment' ? 'bg-nothing-gold text-nothing-black' : 'bg-gray-800 text-gray-500'}`}>
            3
          </div>
          <span className="text-sm">Payment</span>
        </div>
      </div>
    </div>
  );
};

export default CheckoutSteps;
