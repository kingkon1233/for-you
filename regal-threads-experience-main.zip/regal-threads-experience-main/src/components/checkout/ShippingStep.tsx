
import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { ArrowLeft, Truck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const formSchema = z.object({
  name: z.string().min(3, { message: "Name must be at least 3 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  phone: z.string().min(10, { message: "Please enter a valid phone number" }),
  college: z.string().min(3, { message: "Please enter your college name" }),
  year: z.string().min(1, { message: "Please enter your year" }),
  size: z.string().min(1, { message: "Please select a size" }),
  address: z.string().min(5, { message: "Please enter your full address" }),
  coupon: z.string().optional(),
});

export type ShippingFormValues = z.infer<typeof formSchema>;

interface ShippingStepProps {
  onPreviousStep: () => void;
  onNextStep: () => void;
  form: ReturnType<typeof useForm<ShippingFormValues>>;
  discountApplied: boolean;
}

const ShippingStep: React.FC<ShippingStepProps> = ({ 
  onPreviousStep, 
  onNextStep, 
  form,
  discountApplied
}) => {
  const goToPayment = () => {
    const shippingFields = ['name', 'email', 'phone', 'college', 'year', 'size', 'address'];
    const result = form.trigger(shippingFields as any);
    
    if (result) {
      onNextStep();
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-playfair font-bold mb-6">Shipping Information</h2>
      
      <Form {...form}>
        <form className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      className="bg-nothing-black text-white border border-gray-700 focus:border-nothing-gold"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email Address</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="email"
                      className="bg-nothing-black text-white border border-gray-700 focus:border-nothing-gold"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="tel"
                      className="bg-nothing-black text-white border border-gray-700 focus:border-nothing-gold"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="college"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>College Name</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      className="bg-nothing-black text-white border border-gray-700 focus:border-nothing-gold"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="year"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Year</FormLabel>
                  <FormControl>
                    <select
                      {...field}
                      className="w-full px-4 py-2 bg-nothing-black text-white border border-gray-700 rounded-md focus:outline-none focus:border-nothing-gold transition-colors"
                    >
                      <option value="">Select Year</option>
                      <option value="1st">1st Year</option>
                      <option value="2nd">2nd Year</option>
                      <option value="3rd">3rd Year</option>
                      <option value="4th">4th Year</option>
                      <option value="5th">5th Year</option>
                    </select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="size"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>T-Shirt Size</FormLabel>
                  <FormControl>
                    <select
                      {...field}
                      className="w-full px-4 py-2 bg-nothing-black text-white border border-gray-700 rounded-md focus:outline-none focus:border-nothing-gold transition-colors"
                    >
                      <option value="">Select Size</option>
                      <option value="XS">XS</option>
                      <option value="S">S</option>
                      <option value="M">M</option>
                      <option value="L">L</option>
                      <option value="XL">XL</option>
                      <option value="XXL">XXL</option>
                    </select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Delivery Address</FormLabel>
                  <FormControl>
                    <textarea
                      {...field}
                      rows={3}
                      className="w-full px-4 py-2 bg-nothing-black text-white border border-gray-700 rounded-md focus:outline-none focus:border-nothing-gold transition-colors"
                    />
                  </FormControl>
                  <p className="text-xs text-gray-400 mt-1">Default delivery to your college. Modify if needed.</p>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="coupon"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Coupon Code</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        placeholder="Enter coupon code"
                        className="bg-nothing-black text-white border border-gray-700 focus:border-nothing-gold"
                      />
                      {discountApplied && (
                        <span className="absolute right-3 top-2.5 text-green-500 text-sm">
                          Applied!
                        </span>
                      )}
                    </div>
                  </FormControl>
                  <p className="text-xs text-gray-400 mt-1">Use code "GEC10" for 10% off</p>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="flex justify-between pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onPreviousStep}
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              <ArrowLeft size={16} className="mr-2" /> Back to Cart
            </Button>
            
            <Button 
              type="button"
              onClick={goToPayment}
              className="bg-nothing-gold text-nothing-black hover:bg-nothing-lightgold"
            >
              Continue to Payment <Truck size={16} className="ml-2" />
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default ShippingStep;
