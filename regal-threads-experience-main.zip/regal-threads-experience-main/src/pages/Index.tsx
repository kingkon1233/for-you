
import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import FeaturedProducts from "@/components/FeaturedProducts";
import Testimonials from "@/components/Testimonials";
import Newsletter from "@/components/Newsletter";
import Footer from "@/components/Footer";
import AboutUs from "@/components/AboutUs";

export default function Index() {
  return (
    <div className="min-h-screen bg-nothing-black text-white">
      <Navbar />
      <Hero />
      <Features />
      <FeaturedProducts />
      <Testimonials />
      <Newsletter />
      <AboutUs />
      <Footer />
      <Toaster />
      <Sonner />
    </div>
  );
}
