
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

interface CheckoutLayoutProps {
  children: React.ReactNode;
  stepsIndicator?: React.ReactNode;
}

const CheckoutLayout: React.FC<CheckoutLayoutProps> = ({ children, stepsIndicator }) => {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-nothing-black text-white pt-24 pb-16 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="mb-10">
          <button
            onClick={() => navigate('/')}
            className="flex items-center text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft size={16} className="mr-2" /> Back to Home
          </button>
        </div>
        
        {stepsIndicator}
        
        <div className="bg-nothing-charcoal rounded-lg p-6 md:p-8 shadow-xl">
          {children}
        </div>
      </div>
    </div>
  );
};

export default CheckoutLayout;
