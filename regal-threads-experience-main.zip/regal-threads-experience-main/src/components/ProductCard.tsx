
import React, { useState, useRef, useEffect } from 'react';
import { ShoppingBag, Heart, Minus, Plus, IndianRupee, Eye } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/contexts/CartContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  image: string;
  tagline: string;
  type?: string;
  delay?: number;
}

const likeNotifications = [
  "Almost yours! Just one step away from rocking this look!",
  "Aapke pasand ki T-shirt aapka intezaar kar rahi hai!",
  "Liked it? Lock it! Before someone else does!",
  "Your style, your vibe—complete your look now!"
];

const ProductCard: React.FC<ProductCardProps> = ({ id, name, price, image, tagline, type = 'regular', delay = 0 }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [dialogOpen, setDialogOpen] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const { addItem } = useCart();
  
  // Check if product is in favorites
  const [isFavorite, setIsFavorite] = useState(() => {
    try {
      const likedProducts = JSON.parse(localStorage.getItem('likedProducts') || '[]');
      return likedProducts.includes(id);
    } catch (error) {
      return false;
    }
  });

  // Add notification timer for liked products
  useEffect(() => {
    let notificationTimer: NodeJS.Timeout;
    
    if (isFavorite) {
      notificationTimer = setInterval(() => {
        const randomIndex = Math.floor(Math.random() * likeNotifications.length);
        toast({
          title: "Reminder",
          description: likeNotifications[randomIndex],
          className: "toast-enter bg-nothing-charcoal border-nothing-gold",
          duration: 3000, // Auto-dismiss after 3 seconds
        });
      }, 60000); // Show notification every minute
    }
    
    return () => {
      if (notificationTimer) clearInterval(notificationTimer);
    };
  }, [isFavorite, toast]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    
    const { left, top, width, height } = cardRef.current.getBoundingClientRect();
    const x = (e.clientX - left) / width;
    const y = (e.clientY - top) / height;
    
    const rotateX = (y - 0.5) * 10;
    const rotateY = (x - 0.5) * -10;
    
    cardRef.current.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
  };

  const handleMouseLeave = () => {
    if (!cardRef.current) return;
    cardRef.current.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
    setIsHovered(false);
  };

  const addToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    addItem({
      id,
      name,
      price,
      image,
      quantity
    });
    
    toast({
      title: "Added to Cart",
      description: `${name} (x${quantity}) has been added to your cart`,
      className: "toast-enter bg-nothing-charcoal border-nothing-gold",
      duration: 3000, // Auto-dismiss after 3 seconds
    });
  };

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    const newFavoriteState = !isFavorite;
    setIsFavorite(newFavoriteState);
    
    // Update localStorage
    try {
      const likedProducts = JSON.parse(localStorage.getItem('likedProducts') || '[]');
      let updatedLikedProducts;
      
      if (newFavoriteState) {
        updatedLikedProducts = [...new Set([...likedProducts, id])];
      } else {
        updatedLikedProducts = likedProducts.filter((productId: string) => productId !== id);
      }
      
      localStorage.setItem('likedProducts', JSON.stringify(updatedLikedProducts));
      
      // Dispatch storage event to notify other components
      window.dispatchEvent(new Event('storage'));
    } catch (error) {
      console.error('Error updating liked products:', error);
    }
    
    toast({
      title: newFavoriteState ? "Added to Wishlist" : "Removed from Wishlist",
      description: `${name} has been ${newFavoriteState ? "added to" : "removed from"} your wishlist`,
      className: "toast-enter bg-nothing-charcoal border-nothing-gold",
      duration: 3000, // Auto-dismiss after 3 seconds
    });
    
    // Show immediate notification when liking
    if (newFavoriteState) {
      const randomIndex = Math.floor(Math.random() * likeNotifications.length);
      setTimeout(() => {
        toast({
          title: "Reminder",
          description: likeNotifications[randomIndex],
          className: "toast-enter bg-nothing-charcoal border-nothing-gold",
          duration: 3000, // Auto-dismiss after 3 seconds
        });
      }, 2000);
    }
  };

  const incrementQuantity = (e: React.MouseEvent) => {
    e.stopPropagation();
    setQuantity(prev => prev + 1);
  };

  const decrementQuantity = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };
  
  const openProductDialog = () => {
    setDialogOpen(true);
  };

  return (
    <>
      <div 
        ref={cardRef}
        className={cn(
          "product-card bg-nothing-charcoal rounded-lg overflow-hidden shadow-lg transition-all duration-300 cursor-pointer",
          "opacity-0 animate-fade-in"
        )}
        style={{ animationDelay: `${delay}s` }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        onClick={openProductDialog}
      >
        <div className="relative overflow-hidden aspect-[3/4]">
          <img 
            src={image} 
            alt={name} 
            className="product-image w-full h-full object-cover object-center transition-transform duration-500"
          />
          {type === 'premium' && (
            <span className="absolute top-2 right-2 bg-nothing-gold text-nothing-black text-xs px-2 py-1 rounded-full font-bold">
              Premium
            </span>
          )}
          <div className="absolute top-2 left-2 bg-white/20 backdrop-blur-sm p-1 rounded-full opacity-0 transition-opacity duration-300 group-hover:opacity-100">
            <Eye size={16} className="text-white" />
          </div>
        </div>
        
        <div className="p-4">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-white text-lg font-semibold">{name}</h3>
            <span className="text-nothing-gold font-bold flex items-center">
              <IndianRupee size={16} className="mr-1" /> {price}
            </span>
          </div>
          
          <p className="text-gray-300 text-sm italic mb-1">{tagline}</p>
          <p className="text-gray-400 text-xs mb-4">Regular fit t-shirt</p>
          
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center border border-gray-600 rounded-md">
              <button 
                onClick={decrementQuantity}
                className="p-2 text-gray-300 hover:text-white transition-colors"
              >
                <Minus size={16} />
              </button>
              <span className="px-3 text-white">{quantity}</span>
              <button 
                onClick={incrementQuantity}
                className="p-2 text-gray-300 hover:text-white transition-colors"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <button 
              onClick={addToCart}
              className="flex-1 py-2 px-4 bg-nothing-gold text-nothing-black rounded flex items-center justify-center space-x-2 hover:bg-nothing-lightgold transition-colors duration-300"
            >
              <ShoppingBag size={16} />
              <span>Add to Cart</span>
            </button>
            
            <button 
              onClick={toggleFavorite}
              className={cn(
                "p-2 rounded border",
                isFavorite 
                  ? "bg-red-500/10 border-red-500/30 text-red-500" 
                  : "bg-white/5 border-white/20 text-white hover:border-white/40 transition-colors duration-300"
              )}
            >
              <Heart size={16} fill={isFavorite ? "currentColor" : "none"} />
            </button>
          </div>
          
          {isFavorite && (
            <div className="mt-3 text-xs text-center text-red-400">
              Added to your favorites
            </div>
          )}
        </div>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl bg-nothing-black text-white border-nothing-gold">
          <DialogHeader>
            <DialogTitle className="text-xl sm:text-2xl font-playfair">
              {type === 'premium' ? 
                <span className="text-gold-gradient animate-gold-shimmer">{name}</span> :
                name
              }
            </DialogTitle>
          </DialogHeader>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="relative overflow-hidden rounded-md">
              <img src={image} alt={name} className="w-full h-auto object-cover" />
              {type === 'premium' && (
                <div className="absolute top-4 right-4 bg-nothing-gold text-nothing-black px-3 py-1 rounded-full font-bold">
                  Premium
                </div>
              )}
            </div>
            
            <div>
              {type === 'premium' && (
                <Card className="mb-4 bg-gradient-to-r from-nothing-gold/20 to-transparent border-nothing-gold/50">
                  <CardContent className="pt-4">
                    <p className="text-nothing-gold font-semibold">Premium Collection</p>
                    <p className="text-sm text-gray-300 mt-2">
                      Experience excellence with our premium quality fabric and exclusive design. 
                      Crafted for those who demand the best. Limited edition.
                    </p>
                  </CardContent>
                </Card>
              )}
              
              <div className="mb-4">
                <h3 className="text-xl font-semibold mb-2 flex items-center">
                  <IndianRupee size={18} className="text-nothing-gold mr-1" /> 
                  <span className="text-nothing-gold">{price}</span>
                </h3>
                <p className="text-gray-300 italic">{tagline}</p>
                <p className="text-gray-400 text-sm mt-2">Regular fit t-shirt</p>
              </div>
              
              <div className="mb-6">
                <h4 className="font-semibold mb-2">Description</h4>
                <p className="text-gray-300 text-sm leading-relaxed">
                  {type === 'premium' 
                    ? "Our premium college collection t-shirt is crafted from high-quality fabric that offers exceptional comfort and durability. The premium material ensures a soft touch against your skin while maintaining its shape wear after wear. With meticulous attention to detail, this exclusive design showcases your college spirit in a refined manner." 
                    : "This college t-shirt is designed for everyday comfort, featuring a regular fit that suits all body types. Made from soft cotton blend fabric, it's perfect for lectures, campus events, or casual outings. The durable print showcases your college pride and will stay vibrant even after multiple washes."}
                </p>
              </div>
              
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center border border-gray-600 rounded-md">
                  <button 
                    onClick={(e) => decrementQuantity(e)}
                    className="p-2 text-gray-300 hover:text-white transition-colors"
                  >
                    <Minus size={16} />
                  </button>
                  <span className="px-3 text-white">{quantity}</span>
                  <button 
                    onClick={(e) => incrementQuantity(e)}
                    className="p-2 text-gray-300 hover:text-white transition-colors"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <Button 
                  onClick={(e) => addToCart(e)}
                  className="w-full bg-nothing-gold text-nothing-black hover:bg-nothing-lightgold"
                >
                  <ShoppingBag size={16} className="mr-2" />
                  Add to Cart
                </Button>
                
                <Button 
                  onClick={(e) => toggleFavorite(e)}
                  variant="outline" 
                  className={cn(
                    "w-full",
                    isFavorite 
                      ? "bg-red-500/10 border-red-500/30 text-red-500" 
                      : "bg-white/5 border-white/20 text-white hover:border-white/40"
                  )}
                >
                  <Heart size={16} className="mr-2" fill={isFavorite ? "currentColor" : "none"} />
                  {isFavorite ? "Favorited" : "Add to Favorites"}
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ProductCard;
