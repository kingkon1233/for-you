
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { ArrowLeft, CreditCard, Smartphone, AlertCircle } from 'lucide-react';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

const paymentSchema = z.object({
  cardName: z.string().min(3, { message: "Please enter the name on card" }).optional(),
  cardNumber: z.string().min(16, { message: "Please enter a valid card number" }).optional(),
  cardExpiry: z.string().min(5, { message: "Please enter a valid expiry date (MM/YY)" }).optional(),
  cardCVC: z.string().min(3, { message: "Please enter a valid CVC" }).optional(),
  paymentMethod: z.enum(["card", "upi"]),
  upiId: z.string().min(5, { message: "Please enter a valid UPI ID" }).optional(),
  transactionId: z.string().min(12, { message: "Transaction ID must be at least 12 characters" }).optional(),
});

export type PaymentFormValues = z.infer<typeof paymentSchema>;

interface PaymentStepProps {
  onPreviousStep: () => void;
  onSubmit: (data: any) => void;
  form: ReturnType<typeof useForm<any>>;
  totalPrice: number;
  discountApplied: boolean;
  discountAmount: number;
  finalPrice: number;
  handleUpiPayment: () => void;
}

const PaymentStep: React.FC<PaymentStepProps> = ({ 
  onPreviousStep, 
  onSubmit, 
  form,
  totalPrice,
  discountApplied,
  discountAmount,
  finalPrice,
  handleUpiPayment
}) => {
  const watchPaymentMethod = form.watch("paymentMethod");
  const [paymentInitiated, setPaymentInitiated] = useState(false);

  return (
    <div>
      <h2 className="text-2xl font-playfair font-bold mb-6">Payment Information</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="border border-gray-700 rounded-lg p-4 mb-6">
            <div className="flex space-x-6">
              <div className="flex items-center opacity-50">
                <input 
                  type="radio" 
                  id="payCard" 
                  value="card" 
                  disabled
                  className="w-4 h-4 text-nothing-gold bg-nothing-black border-gray-700 focus:ring-nothing-gold"
                />
                <label htmlFor="payCard" className="ml-2 text-white">Credit/Debit Card</label>
              </div>
              
              <div className="flex items-center">
                <input 
                  type="radio" 
                  id="payUpi" 
                  value="upi" 
                  checked={watchPaymentMethod === "upi"}
                  onChange={() => form.setValue("paymentMethod", "upi")}
                  className="w-4 h-4 text-nothing-gold bg-nothing-black border-gray-700 focus:ring-nothing-gold"
                />
                <label htmlFor="payUpi" className="ml-2 text-white">UPI Payment</label>
              </div>
            </div>
          </div>
          
          {watchPaymentMethod === "card" && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Coming Soon</AlertTitle>
              <AlertDescription>
                Credit/Debit card payment is coming soon. Please use UPI payment for now.
              </AlertDescription>
            </Alert>
          )}
          
          {watchPaymentMethod === "upi" && (
            <div className="space-y-6">
              <FormField
                control={form.control}
                name="upiId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>UPI ID</FormLabel>
                    <FormControl>
                      <div className="flex space-x-4">
                        <Input
                          {...field}
                          placeholder="yourname@upi"
                          className="flex-1 bg-nothing-black text-white border border-gray-700 focus:border-nothing-gold"
                          value="jatin@ybl"
                          readOnly
                        />
                        <Button 
                          type="button"
                          onClick={() => {
                            handleUpiPayment();
                            setPaymentInitiated(true);
                          }}
                          className="bg-green-600 hover:bg-green-700 text-white"
                        >
                          <Smartphone size={18} className="mr-2" /> Pay Now
                        </Button>
                      </div>
                    </FormControl>
                    <p className="text-sm text-gray-400 mt-2">
                      Pay directly through any UPI app like Google Pay, PhonePe, Paytm, etc.
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {paymentInitiated && (
                <FormField
                  control={form.control}
                  name="transactionId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Transaction ID</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Enter your payment transaction ID (min 12 characters)"
                          className="bg-nothing-black text-white border border-gray-700 focus:border-nothing-gold"
                        />
                      </FormControl>
                      <p className="text-sm text-gray-400 mt-2">
                        Please enter the transaction ID from your UPI payment to complete your order (minimum 12 characters)
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>
          )}
          
          <div className="mt-8 border-t border-gray-700 pt-6">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹{totalPrice.toFixed(2)}</span>
              </div>
              
              {discountApplied && (
                <div className="flex justify-between text-green-500">
                  <span>Discount (10%)</span>
                  <span>-₹{discountAmount.toFixed(2)}</span>
                </div>
              )}
              
              <div className="flex justify-between text-lg font-semibold pt-2 border-t border-gray-700">
                <span>Total</span>
                <span className="text-nothing-gold">₹{finalPrice.toFixed(2)}</span>
              </div>
            </div>
            
            <div className="flex justify-between pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={onPreviousStep}
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                <ArrowLeft size={16} className="mr-2" /> Back to Shipping
              </Button>
              
              <Button 
                type="submit"
                className="bg-nothing-gold text-nothing-black hover:bg-nothing-lightgold"
                disabled={watchPaymentMethod === "upi" && (!paymentInitiated || !form.getValues("transactionId") || (form.getValues("transactionId")?.length || 0) < 12)}
              >
                Place Order <CreditCard size={16} className="ml-2" />
              </Button>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default PaymentStep;
