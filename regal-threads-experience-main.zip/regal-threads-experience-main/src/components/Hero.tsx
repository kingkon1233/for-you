
import React, { useEffect, useRef } from 'react';
import { ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  const parallaxRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const subtitleRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!parallaxRef.current) return;
      
      const x = e.clientX / window.innerWidth;
      const y = e.clientY / window.innerHeight;
      
      const moveX = x * 20 - 10;
      const moveY = y * 20 - 10;
      
      if (titleRef.current) {
        titleRef.current.style.transform = `translate3d(${moveX * -0.5}px, ${moveY * -0.5}px, 0)`;
      }
      
      if (subtitleRef.current) {
        subtitleRef.current.style.transform = `translate3d(${moveX * 0.3}px, ${moveY * 0.3}px, 0)`;
      }
    };

    document.addEventListener('mousemove', handleMouseMove);
    
    const elements = [titleRef.current, subtitleRef.current, ctaRef.current];
    elements.forEach(el => {
      if (el) el.style.opacity = '1';
    });
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const scrollToProducts = () => {
    const productsSection = document.getElementById('featured-products');
    if (productsSection) {
      productsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-nothing-black">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-gradient-to-b from-nothing-black via-nothing-black/20 to-nothing-black"></div>
      </div>
      
      <div ref={parallaxRef} className="container mx-auto px-4 relative z-10 parallax-container">
        <div 
          ref={titleRef} 
          className="opacity-0 transition-opacity duration-1000 parallax-item"
          style={{ transitionDelay: '0.3s' }}
        >
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-playfair font-bold mb-4 text-center">
            <span className="block text-gold-gradient animate-gold-shimmer">NOTHING</span>
            <span className="block text-white">IS EVERYTHING</span>
          </h1>
        </div>
        
        <div 
          ref={subtitleRef} 
          className="opacity-0 transition-opacity duration-1000 parallax-item text-center max-w-2xl mx-auto"
          style={{ transitionDelay: '0.6s' }}
        >
          <p className="text-gray-300 text-lg md:text-xl mb-8">
            Premium collegiate apparel for those who understand that true royalty isn't just worn, it's embodied.
          </p>
        </div>
        
        <div 
          ref={ctaRef} 
          className="opacity-0 transition-opacity duration-1000 text-center"
          style={{ transitionDelay: '0.9s' }}
        >
          <button 
            onClick={scrollToProducts}
            className="animated-button px-8 py-3 bg-nothing-gold text-nothing-black font-bold tracking-wide uppercase rounded hover:bg-nothing-lightgold transition-all duration-300"
          >
            Explore Collection
          </button>
        </div>
      </div>
      
      <div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 cursor-pointer animate-bounce"
        onClick={scrollToProducts}
      >
        <ArrowDown size={24} className="text-nothing-gold" />
      </div>
    </section>
  );
};

export default Hero;
