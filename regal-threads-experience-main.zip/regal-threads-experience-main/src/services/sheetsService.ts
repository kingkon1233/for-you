
/**
 * Service for integrating with Google Sheets
 */

const SHEETS_API_ENDPOINT = "https://script.google.com/macros/s/AKfycbzcw7wwLCcaGbOXvhZ1cYDGYHbWdwGJJSdMEUn6kx_fUTFqjXYXNc1C4lbKJbjDPQZi/exec";

export interface PremiumOrderData {
  orderId: string;
  productName: string;
  customerName: string;
  email: string;
  date: string;
}

/**
 * Generate a unique order ID for premium products
 */
export const generatePremiumOrderId = (): string => {
  const prefix = "EXCL";
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${prefix}-${timestamp}-${random}`;
};

/**
 * Generate a unique order ID for regular products
 */
export const generateRegularOrderId = (): string => {
  const prefix = "REG";
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${prefix}-${timestamp}-${random}`;
};

/**
 * Submit premium order data to Google Sheets
 */
export const submitPremiumOrderToSheets = async (orderData: PremiumOrderData): Promise<boolean> => {
  try {
    const response = await fetch(SHEETS_API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(orderData),
    });
    
    if (!response.ok) {
      console.error('Failed to submit premium order to sheets:', await response.text());
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error submitting premium order to sheets:', error);
    return false;
  }
};

/**
 * Submit order data to Google Sheets
 */
export const submitOrderToSheets = async (orderData: any): Promise<boolean> => {
  try {
    console.log("Submitting order to Google Sheets:", orderData);
    
    const formData = new FormData();
    formData.append('customerName', orderData.customer.name);
    formData.append('email', orderData.customer.email);
    formData.append('phone', orderData.customer.phone);
    formData.append('collegeName', orderData.customer.college);
    formData.append('tshirtSize', orderData.customer.size);
    formData.append('year', orderData.customer.year);
    formData.append('couponCode', orderData.customer.coupon || "None");
    formData.append('transactionId', orderData.customer.transactionId || "None");
    formData.append('totalAmount', orderData.totalAmount.toString());
    formData.append('orderId', orderData.orderId || "None");
    
    // Send data to Google Sheets - use await to make sure it completes
    try {
      await fetch(SHEETS_API_ENDPOINT, {
        method: 'POST',
        body: formData,
        mode: 'no-cors'
      });
      console.log("Data sent to Google Sheets successfully");
      return true;
    } catch (error) {
      console.error("Error sending data to Google Sheets:", error);
      // Still return true to ensure the order process completes for the user
      return true;
    }
  } catch (error) {
    console.error("Error preparing data for Google Sheets:", error);
    return false;
  }
};
