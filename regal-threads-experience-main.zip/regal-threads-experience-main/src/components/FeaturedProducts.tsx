
import React, { useEffect, useRef } from 'react';
import ProductCard from './ProductCard';

const productsData = [
  {
    id: "1",
    name: "College Regular Fit Tee",
    price: 269,
    image: "https://i.ibb.co/4RQF858c/Screenshot-2025-03-31-080114.png",
    tagline: "Perfect for everyday campus wear",
    type: "regular"
  },
  {
    id: "2",
    name: "Classic College Edition",
    price: 269,
    image: "https://i.ibb.co/Xrj1Rtx6/Screenshot-2025-03-31-080036.png",
    tagline: "Regular fit, exceptional comfort for lectures",
    type: "regular"
  },
  {
    id: "3",
    name: "Premium College Collection",
    price: 399,
    image: "https://i.ibb.co/jqcXL75/Screenshot-2025-03-31-080309.png",
    tagline: "Premium quality fabric with stylish design",
    type: "premium"
  },
  {
    id: "4",
    name: "Signature College Tee",
    price: 269,
    image: "https://i.ibb.co/8nGhyYQG/Screenshot-2025-03-31-080210.png",
    tagline: "Regular fit t-shirt with your college spirit",
    type: "regular"
  },
  {
    id: "5",
    name: "Campus Life Regular Fit",
    price: 269,
    image: "https://i.ibb.co/ch4LrgqJ/Screenshot-2025-03-31-080244.png",
    tagline: "Show your college pride with this regular fit tee",
    type: "regular"
  },
  {
    id: "6",
    name: "College Spirit Tee",
    price: 269,
    image: "https://i.ibb.co/zhhhJ2MH/Screenshot-2025-03-31-075950.png",
    tagline: "Regular fit t-shirt for the true college enthusiast",
    type: "regular"
  },
  {
    id: "7",
    name: "Campus Everyday Collection",
    price: 269,
    image: "https://i.ibb.co/MDC9pLkk/Screenshot-2025-03-31-080344.png",
    tagline: "Regular fit t-shirt perfect for any college day",
    type: "regular"
  }
];

const FeaturedProducts: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const premiumRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observerOptions = {
      threshold: 0.2,
      rootMargin: '0px 0px -100px 0px'
    };

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          if (entry.target === titleRef.current) {
            titleRef.current.classList.add('animate-fade-in');
          } else if (entry.target === subtitleRef.current) {
            subtitleRef.current.classList.add('animate-fade-in');
          } else if (entry.target === premiumRef.current) {
            premiumRef.current.classList.add('animate-fade-in');
          }
        }
      });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);
    
    if (titleRef.current) observer.observe(titleRef.current);
    if (subtitleRef.current) observer.observe(subtitleRef.current);
    if (premiumRef.current) observer.observe(premiumRef.current);

    return () => {
      if (titleRef.current) observer.unobserve(titleRef.current);
      if (subtitleRef.current) observer.unobserve(subtitleRef.current);
      if (premiumRef.current) observer.unobserve(premiumRef.current);
    };
  }, []);

  // Separate premium products from regular ones
  const premiumProducts = productsData.filter(product => product.type === 'premium');
  const regularProducts = productsData.filter(product => product.type !== 'premium');
  
  // Split regular products into two halves for displaying before and after premium
  const firstHalfRegular = regularProducts.slice(0, Math.ceil(regularProducts.length / 2));
  const secondHalfRegular = regularProducts.slice(Math.ceil(regularProducts.length / 2));

  return (
    <section 
      id="featured-products" 
      ref={sectionRef} 
      className="py-20 px-4 bg-nothing-black relative"
    >
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 
            ref={titleRef}
            className="text-4xl md:text-5xl font-playfair font-bold mb-4 opacity-0"
          >
            <span className="text-gold-gradient animate-gold-shimmer">Featured</span> Collection
          </h2>
          <p 
            ref={subtitleRef}
            className="text-gray-300 max-w-2xl mx-auto opacity-0"
            style={{ transitionDelay: '0.2s' }}
          >
            Discover our premium selection of college T-shirts designed to make you stand out on campus. Each piece is crafted with precision and passion.
          </p>
        </div>
        
        {/* First half of regular products with improved spacing */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {firstHalfRegular.map((product, index) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              price={product.price}
              image={product.image}
              tagline={product.tagline}
              type={product.type}
              delay={0.1 + index * 0.1}
            />
          ))}
        </div>
        
        {/* Premium Collection Section in the middle with centered image */}
        {premiumProducts.length > 0 && (
          <div 
            ref={premiumRef}
            className="mb-16 p-6 rounded-lg border border-nothing-gold/30 bg-gradient-to-r from-nothing-gold/10 to-transparent opacity-0"
            style={{ transitionDelay: '0.3s' }}
          >
            <div className="text-center mb-8">
              <h3 className="text-3xl font-playfair font-bold mb-3">
                <span className="text-gold-gradient animate-gold-shimmer">Exclusive Premium</span> Collection
              </h3>
              <p className="text-gray-300 max-w-2xl mx-auto">
                Elevate your college wardrobe with our exclusive premium collection. Crafted with superior fabrics and distinctive designs, these limited edition pieces are made for those who appreciate exceptional quality.
              </p>
            </div>
            
            <div className="flex justify-center">
              {premiumProducts.map((product, index) => (
                <div className="transform hover:scale-105 transition-transform duration-300 max-w-md" key={product.id}>
                  <ProductCard
                    id={product.id}
                    name={product.name}
                    price={product.price}
                    image={product.image}
                    tagline={product.tagline}
                    type={product.type}
                    delay={0.1 + index * 0.1}
                  />
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Second half of regular products with improved spacing */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {secondHalfRegular.map((product, index) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              price={product.price}
              image={product.image}
              tagline={product.tagline}
              type={product.type}
              delay={0.1 + index * 0.1}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
