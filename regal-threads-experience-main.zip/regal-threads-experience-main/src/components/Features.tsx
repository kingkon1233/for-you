
import React, { useEffect, useRef } from 'react';
import { Crown, Shield, Award, Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FeatureProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  delay: number;
}

const Feature: React.FC<FeatureProps> = ({ icon, title, description, delay }) => {
  const featureRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && featureRef.current) {
            featureRef.current.classList.add('animate-fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (featureRef.current) {
      observer.observe(featureRef.current);
    }

    return () => {
      if (featureRef.current) {
        observer.unobserve(featureRef.current);
      }
    };
  }, []);

  return (
    <div 
      ref={featureRef}
      className={cn(
        "flex flex-col items-center text-center p-6 hover-rise opacity-0",
        "bg-nothing-charcoal/50 backdrop-blur-sm rounded-lg gold-border-gradient"
      )}
      style={{ animationDelay: `${delay}s` }}
    >
      <div className="p-4 rounded-full bg-nothing-gold/10 mb-4 text-nothing-gold">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2 font-playfair">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  );
};

const Features: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && titleRef.current) {
            titleRef.current.classList.add('animate-fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (titleRef.current) {
      observer.observe(titleRef.current);
    }

    return () => {
      if (titleRef.current) {
        observer.unobserve(titleRef.current);
      }
    };
  }, []);

  const features = [
    {
      icon: <Crown size={28} />,
      title: "Premium Quality",
      description: "Expertly crafted with the finest materials for unparalleled comfort and durability.",
      delay: 0.1
    },
    {
      icon: <Shield size={28} />,
      title: "Exclusive Designs",
      description: "Limited edition designs that set you apart and showcase your unique identity.",
      delay: 0.2
    },
    {
      icon: <Award size={28} />,
      title: "Symbol of Status",
      description: "More than apparel - a statement that reflects your achievements and aspirations.",
      delay: 0.3
    },
    {
      icon: <Star size={28} />,
      title: "Legacy Experience",
      description: "Join an elite community that values excellence, pride, and authentic expression.",
      delay: 0.4
    }
  ];

  return (
    <section
      ref={sectionRef}
      className="py-20 px-4 bg-gradient-to-b from-nothing-black to-nothing-charcoal"
    >
      <div className="container mx-auto">
        <h2
          ref={titleRef}
          className="text-4xl md:text-5xl font-playfair font-bold text-center mb-16 opacity-0"
        >
          Why Choose <span className="text-gold-gradient animate-gold-shimmer">NOTHING</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Feature
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              delay={feature.delay}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
