
import React from 'react';

const AboutUs: React.FC = () => {
  return (
    <section id="about-us" className="py-16 px-4 bg-nothing-charcoal">
      <div className="container mx-auto">
        <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-8 text-center">
          <span className="text-gold-gradient animate-gold-shimmer">About</span> Us
        </h2>
        
        <div className="max-w-3xl mx-auto text-gray-300 space-y-4">
          <p>
            We are a passionate team of college students who understand the importance of quality and style in campus life. Our mission is to provide comfortable, stylish, and affordable t-shirts that represent your college spirit.
          </p>
          
          <p>
            Founded in 2023, our brand has quickly become the go-to choice for college students across India. We pride ourselves on using high-quality materials, creating unique designs, and delivering exceptional customer service.
          </p>
          
          <p>
            Each of our t-shirts is crafted with attention to detail, ensuring durability, comfort, and style that lasts throughout your college journey. Whether you're attending lectures, participating in events, or hanging out with friends, our t-shirts are designed to make you look and feel great.
          </p>
          
          <p className="font-medium mt-8">
            Have questions or need assistance? Feel free to reach out to us at <a href="mailto:contact@collegetees.com" className="text-nothing-gold hover:underline">contact@collegetees.com</a>.
          </p>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
