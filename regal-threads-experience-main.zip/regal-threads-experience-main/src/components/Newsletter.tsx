
import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim()) {
      toast({
        title: "Error",
        description: "Please enter your email address",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Success!",
        description: "You've successfully joined our royal community.",
        className: "bg-nothing-charcoal border-nothing-gold",
      });
      setEmail('');
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <section className="py-20 px-4 bg-nothing-charcoal relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-gradient-to-t from-nothing-gold/10 to-transparent"></div>
      </div>
      
      <div className="container mx-auto max-w-4xl relative z-10">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
            Join the <span className="text-gold-gradient animate-gold-shimmer">Royal Circle</span>
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Subscribe to receive exclusive offers, early access to new collections, and royal treatment.
          </p>
        </div>
        
        <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4 max-w-2xl mx-auto">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Your email address"
            className="flex-1 px-6 py-4 bg-nothing-black text-white border border-gray-700 rounded-md focus:outline-none focus:border-nothing-gold transition-colors duration-300"
            required
          />
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-4 bg-nothing-gold text-nothing-black font-bold tracking-wide uppercase rounded-md hover:bg-nothing-lightgold transition-colors duration-300 flex items-center justify-center space-x-2 animated-button"
          >
            {isSubmitting ? (
              <span>Subscribing...</span>
            ) : (
              <>
                <span>Subscribe</span>
                <Send size={16} />
              </>
            )}
          </button>
        </form>
        
        <p className="text-gray-400 text-sm text-center mt-4">
          By subscribing, you agree to receive marketing communications from NOTHING.
        </p>
      </div>
    </section>
  );
};

export default Newsletter;
