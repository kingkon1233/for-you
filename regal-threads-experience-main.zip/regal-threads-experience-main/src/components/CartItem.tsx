
import React from 'react';
import { Minus, Plus, Trash2, IndianRupee } from 'lucide-react';
import { CartItem as CartItemType } from '@/contexts/CartContext';
import { useCart } from '@/contexts/CartContext';

interface CartItemProps {
  item: CartItemType;
}

const CartItem: React.FC<CartItemProps> = ({ item }) => {
  const { updateQuantity, removeItem } = useCart();

  const handleIncrement = () => {
    updateQuantity(item.id, item.quantity + 1);
  };

  const handleDecrement = () => {
    if (item.quantity > 1) {
      updateQuantity(item.id, item.quantity - 1);
    }
  };

  const handleRemove = () => {
    removeItem(item.id);
  };

  return (
    <div className="flex items-center py-4 border-b border-gray-700">
      <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-md">
        <img 
          src={item.image} 
          alt={item.name} 
          className="h-full w-full object-cover object-center"
        />
      </div>
      
      <div className="ml-4 flex-1">
        <h3 className="text-white font-medium">{item.name}</h3>
        <p className="text-nothing-gold flex items-center">
          <IndianRupee size={14} className="mr-1" /> {item.price.toFixed(2)}
        </p>
      </div>
      
      <div className="flex items-center ml-4">
        <button 
          className="p-1 text-gray-300 hover:text-white transition-colors"
          onClick={handleDecrement}
        >
          <Minus size={16} />
        </button>
        <span className="px-2 text-white">{item.quantity}</span>
        <button 
          className="p-1 text-gray-300 hover:text-white transition-colors"
          onClick={handleIncrement}
        >
          <Plus size={16} />
        </button>
      </div>
      
      <div className="ml-4 text-right">
        <p className="text-white font-medium flex items-center justify-end">
          <IndianRupee size={14} className="mr-1" /> {(item.price * item.quantity).toFixed(2)}
        </p>
        <button 
          className="mt-1 text-red-400 hover:text-red-300 transition-colors"
          onClick={handleRemove}
        >
          <Trash2 size={16} />
        </button>
      </div>
    </div>
  );
};

export default CartItem;
