
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface ConfirmationStepProps {
  orderData?: any;
}

const ConfirmationStep: React.FC<ConfirmationStepProps> = ({ orderData }) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Show confirmation toast when component mounts
  useEffect(() => {
    toast({
      title: "Thank you for your order!",
      description: "We'll send further details about your order via WhatsApp soon.",
      className: "bg-green-700 border-green-500",
      duration: 6000,
    });
  }, []);
  
  return (
    <div className="text-center py-10">
      <div className="h-20 w-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
        <Check size={40} className="text-green-500" />
      </div>
      
      <h2 className="text-3xl font-playfair font-bold mb-4">Order Confirmed!</h2>
      <p className="text-gray-300 mb-2 max-w-md mx-auto">
        Thank you for your order. Your custom college t-shirt will be delivered to your college soon.
      </p>
      
      <p className="text-gray-300 mb-6 max-w-md mx-auto">
        We'll send further details about your order via WhatsApp.
      </p>
      
      {orderData?.orderId && (
        <div className="mb-6 p-4 bg-nothing-charcoal border border-nothing-gold/30 rounded-lg inline-block">
          <p className="font-semibold text-nothing-gold">Order ID: {orderData.orderId}</p>
        </div>
      )}
      
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-4">
        <Button 
          onClick={() => navigate('/')}
          className="bg-nothing-gold text-nothing-black hover:bg-nothing-lightgold"
        >
          Continue Shopping
        </Button>
        
        <Button 
          onClick={() => window.open(`https://wa.me/919876543210?text=Hello,%20I%20want%20to%20check%20my%20order%20status%20for%20${orderData?.orderId || 'my%20recent%20order'}`, '_blank')}
          className="bg-green-600 hover:bg-green-700 text-white"
        >
          <Send size={18} className="mr-2" /> Contact on WhatsApp
        </Button>
      </div>
    </div>
  );
};

export default ConfirmationStep;
