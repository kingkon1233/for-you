
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/hooks/use-toast';
import CartItem from '@/components/CartItem';
import { IndianRupee, Heart, ShoppingBag, X, Bell, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { generatePremiumOrderId } from '@/services/sheetsService';

interface OrderNotification {
  id: string;
  message: string;
  date: Date;
  status: 'processing' | 'delivered';
}

interface CartStepProps {
  onNextStep: () => void;
  orderNotifications?: OrderNotification[];
}

// Get liked products from localStorage
const getLikedProducts = () => {
  try {
    return JSON.parse(localStorage.getItem('likedProducts') || '[]');
  } catch (error) {
    console.error('Error parsing liked products:', error);
    return [];
  }
};

const CartStep: React.FC<CartStepProps> = ({ onNextStep, orderNotifications = [] }) => {
  const { items, totalPrice, addItem } = useCart();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [likedProducts, setLikedProducts] = useState(getLikedProducts());

  // Get product data from local storage or use default
  const productsData = [
    {
      id: "1",
      name: "College Regular Fit Tee",
      price: 269,
      image: "https://i.ibb.co/4RQF858c/Screenshot-2025-03-31-080114.png",
      tagline: "Perfect for everyday campus wear",
      type: "regular"
    },
    {
      id: "2",
      name: "Classic College Edition",
      price: 269,
      image: "https://i.ibb.co/Xrj1Rtx6/Screenshot-2025-03-31-080036.png",
      tagline: "Regular fit, exceptional comfort for lectures",
      type: "regular"
    },
    {
      id: "3",
      name: "Premium College Collection",
      price: 399,
      image: "https://i.ibb.co/jqcXL75/Screenshot-2025-03-31-080309.png",
      tagline: "Premium quality fabric with stylish design",
      type: "premium"
    },
    {
      id: "4",
      name: "Signature College Tee",
      price: 269,
      image: "https://i.ibb.co/8nGhyYQG/Screenshot-2025-03-31-080210.png",
      tagline: "Regular fit t-shirt with your college spirit",
      type: "regular"
    },
    {
      id: "5",
      name: "Campus Life Regular Fit",
      price: 269,
      image: "https://i.ibb.co/ch4LrgqJ/Screenshot-2025-03-31-080244.png",
      tagline: "Show your college pride with this regular fit tee",
      type: "regular"
    },
    {
      id: "6",
      name: "College Spirit Tee",
      price: 269,
      image: "https://i.ibb.co/zhhhJ2MH/Screenshot-2025-03-31-075950.png",
      tagline: "Regular fit t-shirt for the true college enthusiast",
      type: "regular"
    },
    {
      id: "7",
      name: "Campus Everyday Collection",
      price: 269,
      image: "https://i.ibb.co/MDC9pLkk/Screenshot-2025-03-31-080344.png",
      tagline: "Regular fit t-shirt perfect for any college day",
      type: "regular"
    }
  ];
  
  useEffect(() => {
    // Update liked products when localStorage changes
    const handleStorageChange = () => {
      setLikedProducts(getLikedProducts());
    };
    
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const goToShipping = () => {
    if (items.length === 0) {
      toast({
        title: "Empty Cart",
        description: "Please add items to your cart before proceeding to checkout.",
        variant: "destructive",
      });
      return;
    }
    
    // Generate exclusive IDs for premium products
    const hasPremiumItems = items.some(item => {
      const productData = productsData.find(p => p.id === item.id);
      return productData?.type === 'premium';
    });
    
    if (hasPremiumItems) {
      const exclusiveId = generatePremiumOrderId();
      localStorage.setItem('exclusiveOrderId', exclusiveId);
      
      toast({
        title: "Exclusive Order Created",
        description: `Your premium order ID is: ${exclusiveId}`,
        className: "bg-nothing-charcoal border-nothing-gold text-white",
      });
    }
    
    onNextStep();
  };

  const addToCart = (product) => {
    const productToAdd = {
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1
    };
    
    addItem(productToAdd);
    
    // Remove from liked products
    const updatedLikedProducts = likedProducts.filter(id => id !== product.id);
    localStorage.setItem('likedProducts', JSON.stringify(updatedLikedProducts));
    setLikedProducts(updatedLikedProducts);
    
    // Show toast that auto-dismisses
    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart`,
      className: "toast-enter bg-nothing-charcoal border-nothing-gold",
      duration: 3000, // Auto-dismiss after 3 seconds
    });
  };
  
  const removeFromWishlist = (productId) => {
    const updatedLikedProducts = likedProducts.filter(id => id !== productId);
    localStorage.setItem('likedProducts', JSON.stringify(updatedLikedProducts));
    setLikedProducts(updatedLikedProducts);
    
    toast({
      title: "Removed from Wishlist",
      description: "Item has been removed from your wishlist",
      className: "bg-nothing-charcoal border-red-500",
      duration: 3000, // Auto-dismiss after 3 seconds
    });
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div>
      <h2 className="text-2xl font-playfair font-bold mb-6">Your Cart</h2>
      
      {items.length === 0 ? (
        <div className="text-center py-10">
          <p className="text-gray-400 mb-6">Your cart is empty</p>
          <Button 
            onClick={() => navigate('/')}
            className="bg-nothing-gold text-nothing-black hover:bg-nothing-lightgold"
          >
            Continue Shopping
          </Button>
        </div>
      ) : (
        <>
          <div className="space-y-4">
            {items.map(item => (
              <CartItem key={item.id} item={item} />
            ))}
          </div>
          
          {likedProducts.length > 0 && (
            <div className="mt-8 pt-6 border-t border-gray-700">
              <div className="flex items-center mb-4">
                <Heart className="text-red-400 mr-2" size={20} />
                <h3 className="text-lg font-medium">Your Wishlist</h3>
              </div>
              
              <div className="text-sm text-gray-300 mb-4">
                <p>You've liked {likedProducts.length} product(s). Add them to your cart before they sell out!</p>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {productsData.filter(product => likedProducts.includes(product.id)).map(product => (
                  <div key={product.id} className="flex items-center p-3 border border-gray-700 rounded-lg hover:border-nothing-gold transition-colors duration-300 bg-nothing-charcoal/50">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-16 h-16 object-cover rounded"
                    />
                    <div className="ml-3 flex-1">
                      <p className="text-sm font-medium">{product.name}</p>
                      <p className="text-xs text-nothing-gold flex items-center mt-1">
                        <IndianRupee size={12} className="mr-1" /> {product.price}
                      </p>
                      <p className="text-xs text-gray-400 mt-1">{product.tagline}</p>
                    </div>
                    <div className="flex flex-col space-y-2">
                      <Button
                        onClick={() => addToCart(product)}
                        variant="outline"
                        size="sm"
                        className="border-nothing-gold text-nothing-gold hover:bg-nothing-gold hover:text-nothing-black transition-all duration-300"
                      >
                        <ShoppingBag size={14} className="mr-1" /> Add
                      </Button>
                      <Button
                        onClick={() => removeFromWishlist(product.id)}
                        variant="outline"
                        size="sm"
                        className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white transition-all duration-300"
                      >
                        <X size={14} className="mr-1" /> Remove
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {orderNotifications && orderNotifications.length > 0 && (
            <div className="mt-8 pt-6 border-t border-gray-700">
              <div className="flex items-center mb-4">
                <Bell className="text-blue-400 mr-2" size={20} />
                <h3 className="text-lg font-medium">Your Notifications</h3>
              </div>
              
              <div className="space-y-3">
                {orderNotifications.map(notification => (
                  <div 
                    key={notification.id} 
                    className={`p-3 border rounded-lg flex items-start ${
                      notification.status === 'delivered' 
                        ? 'border-green-500/30 bg-green-500/10' 
                        : 'border-blue-500/30 bg-blue-500/10'
                    }`}
                  >
                    {notification.status === 'delivered' ? (
                      <Check className="text-green-500 mr-3 mt-1 flex-shrink-0" size={18} />
                    ) : (
                      <Bell className="text-blue-400 mr-3 mt-1 flex-shrink-0" size={18} />
                    )}
                    <div className="flex-1">
                      <p className="text-sm">{notification.message}</p>
                      <div className="flex justify-between mt-1">
                        <span className="text-xs text-gray-400">
                          {formatDate(notification.date)}
                        </span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          notification.status === 'delivered' 
                            ? 'bg-green-500/20 text-green-400' 
                            : 'bg-blue-500/20 text-blue-400'
                        }`}>
                          {notification.status === 'delivered' ? 'Delivered' : 'Processing'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <div className="mt-8 border-t border-gray-700 pt-6">
            <div className="flex justify-between text-lg font-semibold">
              <span>Total</span>
              <span className="text-nothing-gold flex items-center">
                <IndianRupee size={18} className="mr-1" /> {totalPrice.toFixed(2)}
              </span>
            </div>
            
            <div className="mt-6 space-x-4 flex justify-end">
              <Button
                variant="outline"
                onClick={() => navigate('/')}
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                Continue Shopping
              </Button>
              
              <Button 
                onClick={goToShipping}
                className="bg-nothing-gold text-nothing-black hover:bg-nothing-lightgold"
              >
                Proceed to Checkout
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default CartStep;
