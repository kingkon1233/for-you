
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/hooks/use-toast';

import CheckoutLayout from '@/components/checkout/CheckoutLayout';
import CheckoutSteps from '@/components/checkout/CheckoutSteps';
import CartStep from '@/components/checkout/CartStep';
import ShippingStep, { ShippingFormValues } from '@/components/checkout/ShippingStep';
import PaymentStep from '@/components/checkout/PaymentStep';
import ConfirmationStep from '@/components/checkout/ConfirmationStep';
import { generatePremiumOrderId, generateRegularOrderId, submitOrderToSheets } from '@/services/sheetsService';

const formSchema = z.object({
  name: z.string().min(3, { message: "Name must be at least 3 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  phone: z.string().min(10, { message: "Please enter a valid phone number" }),
  college: z.string().min(3, { message: "Please enter your college name" }),
  year: z.string().min(1, { message: "Please enter your year" }),
  size: z.string().min(1, { message: "Please select a size" }),
  address: z.string().min(5, { message: "Please enter your full address" }),
  coupon: z.string().optional(),
  cardName: z.string().min(3, { message: "Please enter the name on card" }).optional(),
  cardNumber: z.string().min(16, { message: "Please enter a valid card number" }).optional(),
  cardExpiry: z.string().min(5, { message: "Please enter a valid expiry date (MM/YY)" }).optional(),
  cardCVC: z.string().min(3, { message: "Please enter a valid CVC" }).optional(),
  paymentMethod: z.enum(["card", "upi"]),
  upiId: z.string().min(5, { message: "Please enter a valid UPI ID" }).optional(),
  transactionId: z.string().min(12, { message: "Transaction ID must be at least 12 characters" }).optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface OrderNotification {
  id: string;
  message: string;
  date: Date;
  status: 'processing' | 'delivered';
}

const Checkout: React.FC = () => {
  const navigate = useNavigate();
  const { items, totalPrice, clearCart } = useCart();
  const { toast } = useToast();
  const [step, setStep] = useState<'cart' | 'shipping' | 'payment' | 'confirmation'>('cart');
  const [discountApplied, setDiscountApplied] = useState(false);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [finalPrice, setFinalPrice] = useState(totalPrice);
  const [orderData, setOrderData] = useState<any>(null);
  
  // Load notifications from localStorage
  const [orderNotifications, setOrderNotifications] = useState<OrderNotification[]>(() => {
    try {
      const saved = localStorage.getItem('orderNotifications');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error("Failed to load notifications:", e);
      return [];
    }
  });
  
  // Update localStorage when notifications change
  useEffect(() => {
    localStorage.setItem('orderNotifications', JSON.stringify(orderNotifications));
  }, [orderNotifications]);
  
  // Auto-update notification status after 7 days
  useEffect(() => {
    const interval = setInterval(() => {
      setOrderNotifications(prevNotifications => 
        prevNotifications.map(notification => {
          const daysSinceOrder = Math.floor((new Date().getTime() - new Date(notification.date).getTime()) / (1000 * 60 * 60 * 24));
          
          if (daysSinceOrder >= 7 && notification.status === 'processing') {
            return { ...notification, status: 'delivered' };
          }
          return notification;
        })
      );
    }, 1000 * 60 * 60); // Check every hour
    
    return () => clearInterval(interval);
  }, []);
  
  useEffect(() => {
    const newFinalPrice = discountApplied ? totalPrice * 0.9 : totalPrice; // 10% discount
    setFinalPrice(newFinalPrice);
  }, [totalPrice, discountApplied]);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      college: "",
      year: "",
      size: "",
      address: "In your college",
      coupon: "",
      cardName: "",
      cardNumber: "",
      cardExpiry: "",
      cardCVC: "",
      paymentMethod: "upi",
      upiId: "jatin@ybl",
      transactionId: "",
    },
  });

  const watchCoupon = form.watch("coupon");
  
  useEffect(() => {
    if (watchCoupon === "GEC10" && !discountApplied) {
      setDiscountApplied(true);
      setDiscountAmount(totalPrice * 0.1); // 10% of total
      toast({
        title: "Coupon Applied",
        description: "GEC10 coupon applied! You got 10% off.",
        className: "bg-nothing-charcoal border-nothing-gold",
      });
    } else if (watchCoupon !== "GEC10" && discountApplied) {
      setDiscountApplied(false);
      setDiscountAmount(0);
    }
  }, [watchCoupon, discountApplied, totalPrice, toast]);

  const onSubmit = async (data: FormValues) => {
    try {
      if (data.paymentMethod === "upi" && (!data.transactionId || data.transactionId.length < 12)) {
        toast({
          title: "Transaction ID Required",
          description: "Please enter your UPI transaction ID with at least 12 characters to complete your order.",
          variant: "destructive",
        });
        return;
      }
      
      // Check if any premium items in cart
      const hasPremiumItems = items.some(item => {
        const itemName = item.name.toLowerCase();
        return itemName.includes('premium') || itemName.includes('exclusive');
      });
      
      // Generate appropriate order ID
      const orderId = hasPremiumItems ? generatePremiumOrderId() : generateRegularOrderId();
      
      // Prepare order data
      const orderData = {
        orderId: orderId,
        customer: {
          name: data.name,
          email: data.email,
          phone: data.phone,
          college: data.college,
          year: data.year,
          size: data.size,
          address: data.address,
          coupon: data.coupon,
          paymentMethod: data.paymentMethod,
          transactionId: data.transactionId
        },
        items: items.map(item => ({
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
          total: item.price * item.quantity
        })),
        totalAmount: finalPrice,
        discount: discountAmount,
        orderDate: new Date().toISOString()
      };

      setOrderData(orderData);
      console.log("Order data prepared:", orderData);
      
      // Submit data to Google Sheets
      const submitted = await submitOrderToSheets(orderData);
      
      if (submitted) {
        // Add to notifications (with proper typing)
        const newNotification: OrderNotification = {
          id: orderId,
          message: `Your order #${orderId} has been placed successfully. Total amount: ₹${finalPrice.toFixed(2)}`,
          date: new Date(),
          status: 'processing'
        };
        
        setOrderNotifications(prev => [newNotification, ...prev]);
        
        // Show success message
        toast({
          title: "Order Placed Successfully!",
          description: "Thank you for your order. Further details will be sent to you via WhatsApp.",
          className: "bg-nothing-charcoal border-nothing-gold",
          duration: 5000,
        });
        
        // Clear cart and redirect to home page
        clearCart();
        navigate('/');
      } else {
        toast({
          title: "Warning",
          description: "Your order was processed but we had trouble recording it. Please contact support.",
          variant: "destructive",
        });
        
        // Clear cart and redirect to home page even if there was an issue with sheets
        clearCart();
        navigate('/');
      }
      
    } catch (error) {
      console.error("Error submitting order:", error);
      toast({
        title: "Error",
        description: "There was a problem processing your order. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleUpiPayment = () => {
    // Triggering UPI app on mobile with your UPI ID
    const upiId = form.getValues("upiId") || "jatin@ybl";
    const upiUrl = `upi://pay?pa=${upiId}&pn=NOTHING&am=${finalPrice.toFixed(2)}&cu=INR&tn=College T-shirt Payment`;
    window.location.href = upiUrl;
    
    // For desktop, provide a fallback
    setTimeout(() => {
      toast({
        title: "UPI Payment",
        description: "Please complete payment in your UPI app. If not redirected, please use the UPI ID manually.",
        className: "bg-nothing-charcoal border-nothing-gold",
      });
    }, 1000);
  };

  const handleStepNavigation = (targetStep: 'cart' | 'shipping' | 'payment') => {
    if (items.length === 0 && targetStep !== 'cart') {
      toast({
        title: "Empty Cart",
        description: "Please add items to your cart before proceeding to checkout.",
        variant: "destructive",
      });
      return;
    }

    if (targetStep === 'payment') {
      const shippingFields = ['name', 'email', 'phone', 'college', 'year', 'size', 'address'];
      const isValid = form.trigger(shippingFields as any);
      if (!isValid) return;
    }

    setStep(targetStep);
  };

  return (
    <CheckoutLayout
      stepsIndicator={
        <CheckoutSteps 
          currentStep={step} 
          onStepClick={handleStepNavigation}
          isCartValid={items.length > 0}
          isShippingValid={form.formState.isValid}
        />
      }
    >
      {step === 'cart' && (
        <CartStep 
          onNextStep={() => setStep('shipping')} 
          orderNotifications={orderNotifications}
        />
      )}
      
      {step === 'shipping' && (
        <ShippingStep 
          onPreviousStep={() => setStep('cart')} 
          onNextStep={() => setStep('payment')}
          form={form}
          discountApplied={discountApplied}
        />
      )}
      
      {step === 'payment' && (
        <PaymentStep 
          onPreviousStep={() => setStep('shipping')} 
          onSubmit={onSubmit}
          form={form}
          totalPrice={totalPrice}
          discountApplied={discountApplied}
          discountAmount={discountAmount}
          finalPrice={finalPrice}
          handleUpiPayment={handleUpiPayment}
        />
      )}
      
      {step === 'confirmation' && <ConfirmationStep orderData={orderData} />}
    </CheckoutLayout>
  );
};

export default Checkout;
